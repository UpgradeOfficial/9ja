def who_be_president():
    return "Major General Mohammed Buhari GCON"

def wetin_dy_sup():
    return "Ohh boy I loyal ooo"


